<?php
namespace beGateway\PaymentMethod;

class Emexvoucher extends Base {
}
?>
