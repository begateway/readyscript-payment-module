<?php
namespace beGateway;

class Capture extends ChildTransaction {
}
?>
